package com.javaproject.bm.DAO;

import java.util.List;

import com.javaproject.bm.api.Conductor;
import com.javaproject.bm.api.ConductorDTO;
import com.javaproject.bm.api.EnabledConductor;

public interface ConductorDAO {

	List<Conductor> loadConductors();

	void saveConductor(ConductorDTO conductorDTO);

	void deleteConductor(String conductorName);

	Conductor getConductor(String conductorName);

	void update(ConductorDTO conductorDTO);

	List<Conductor> searchConductor(String conductorName);

	List<EnabledConductor> enableConductors();

}
