package com.javaproject.bm.DAO;

import java.util.List;

import com.javaproject.bm.api.Staff;
import com.javaproject.bm.api.StaffDTO;

public interface StaffDAO {

	List<Staff> loadStaff();

	Staff getStaff(int staffId);

	void update(StaffDTO staffDTO);

	void deleteStaff(int staffId);

	void saveStaff(StaffDTO staffDTO);

}
