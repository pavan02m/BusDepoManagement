package com.javaproject.bm.DAO;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.javaproject.bm.api.Bus;
import com.javaproject.bm.api.Driver;
import com.javaproject.bm.api.DriverDTO;
import com.javaproject.bm.api.EnabledDriver;
import com.javaproject.bm.rowMapper.BusRowMapper;
import com.javaproject.bm.rowMapper.DriverRowMapper;
import com.javaproject.bm.rowMapper.enabledRowMapper;


@Repository
public class DriverDAOImpl implements DriverDAO {

	@Autowired
	 JdbcTemplate jdbcTemplate;
	
	@Override
	public List<Driver> loadDrivers() {
		// TODO Auto-generated method stub
		 String sql5 = "SELECT driver_name,lastname,email,address,pincode,contact_number,licence_number,authority_number,expiry_date,state_issued FROM javaproject.drivers where enabled=?";
		 
			List<Driver> listOfDrivers = jdbcTemplate.query(sql5, new DriverRowMapper(),"enable");
			 
			return listOfDrivers;
	}

	@Override
	public void saveDriver(DriverDTO driverDTO) {
		// TODO Auto-generated method stub
		java.lang.Object[] sqlparameters2 = {driverDTO.getDriver_name(),driverDTO.getLastname(),driverDTO.getEmail(),driverDTO.getAddress(),driverDTO.getPincode(),driverDTO.getContact_number(),driverDTO.getLicence_number(),driverDTO.getAuthority_number(),driverDTO.getExpiry_date(),driverDTO.getState_issued(),"enable"};
		
		String sql6 = "insert into drivers(driver_name,lastname,email,address,pincode,contact_number,licence_number,authority_number,expiry_date,state_issued,enabled) values(?,?,?,?,?,?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql6, sqlparameters2);
	}

	@Override
	public Driver getDriver(String driverName) {
		String sql = "SELECT * FROM drivers WHERE driver_name = ?";
		Driver driver = jdbcTemplate.queryForObject(sql, new DriverRowMapper(), driverName);
		
		return driver;
	}

	@Override
	public void update(DriverDTO driverDTO) {
		String sql7 = "update drivers set lastname=?, email=?, address=?, pincode=?, contact_number=?, licence_number=?, authority_number=?, expiry_date=?, state_issued=? where driver_name=?";
		jdbcTemplate.update(sql7,driverDTO.getLastname(),driverDTO.getEmail(),driverDTO.getAddress(),driverDTO.getPincode(),driverDTO.getContact_number(),driverDTO.getLicence_number(),driverDTO.getAuthority_number(),driverDTO.getExpiry_date(),driverDTO.getState_issued(),driverDTO.getDriver_name());
	}

	@Override
	public void deleteBus(String driverName) {
		// TODO Auto-generated method stub
		String sql = "delete from drivers where driver_name = ?";
		jdbcTemplate.update(sql, driverName);
	}

	@Override
	public List<Driver> searchDriver(String driverName) {
		
		String sql3 = "SELECT * FROM javaproject.drivers where driver_name=?";

		List<Driver> listOfDriver = jdbcTemplate.query(sql3, new DriverRowMapper(), driverName);
		
		System.out.println(listOfDriver);
		
		return listOfDriver;
	}

	@Override
	public List<EnabledDriver> enableDrivers() {
		
		String sql5 = "SELECT driver_name from enableddriver";
		List<EnabledDriver> listOfDrivers = jdbcTemplate.query(sql5, new enabledRowMapper());
		System.out.println(listOfDrivers);
		return listOfDrivers;
	}

}