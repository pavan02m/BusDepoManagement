package com.javaproject.bm.DAO;

import java.util.List;

import com.javaproject.bm.api.AdminNotificationDTO;
import com.javaproject.bm.api.EmpNotification;
import com.javaproject.bm.api.EmpNotificationDTO;

public interface EmpnotificationDAO {

	void applyLeave(EmpNotificationDTO empNotificationDTO, AdminNotificationDTO adminNotificationDTO);

	List<EmpNotification> loadNotifications();

	void responseRequest(String name);

}
