package com.javaproject.bm.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.javaproject.bm.api.Bus;

public class BusRowMapper implements RowMapper<Bus>{

	@Override
	public Bus mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Bus bus = new Bus();
		
		bus.setBus_id(rs.getInt("bus_id"));
		bus.setBus_no(rs.getString("bus_no"));
		bus.setArrival_time(rs.getFloat("arrival_time"));
		bus.setDispater_time(rs.getFloat("dispater_time"));
		bus.setDriver(rs.getString("driver"));
		bus.setConductor(rs.getString("conductor"));
		bus.setFrom_where(rs.getString("from_where"));
		bus.setTo_where(rs.getString("to_where"));
		return bus;
	}

}
