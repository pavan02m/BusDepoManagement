package com.javaproject.bm.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.javaproject.bm.api.Conductor;
import com.javaproject.bm.api.ConductorDTO;
import com.javaproject.bm.api.EnabledConductor;
import com.javaproject.bm.rowMapper.ConductorRowMapper;
import com.javaproject.bm.rowMapper.EnableCRowMapper;

@Repository
public class ConductorDAOImpl implements ConductorDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public List<Conductor> loadConductors() {
		String sql5 = "SELECT * FROM javaproject.conductors";
		 
		List<Conductor> listOfDrivers = jdbcTemplate.query(sql5, new ConductorRowMapper());
		 
		return listOfDrivers;
	}

	@Override
	public void saveConductor(ConductorDTO conductorDTO) {
		
		java.lang.Object[] sqlparameters2 = {conductorDTO.getConductor_name(),conductorDTO.getLastname(),conductorDTO.getEmail(),conductorDTO.getAddress(),conductorDTO.getPincode(),conductorDTO.getContact_number(),conductorDTO.getLicence_number(),conductorDTO.getAuthority_number(),conductorDTO.getExpiry_date(),conductorDTO.getState_issued()};
		
		String sql6 = "insert into conductors(conductor_name,lastname,email,address,pincode,contact_number,licence_number,authority_number,expiry_date,state_issued) values(?,?,?,?,?,?,?,?,?,?)";
	
		jdbcTemplate.update(sql6, sqlparameters2);
	}

	@Override
	public void deleteConductor(String conductorName) {
		
		String sql = "delete from conductors where conductor_name=?";
		
		jdbcTemplate.update(sql, conductorName);
		
	}

	@Override
	public Conductor getConductor(String conductorName) {
		
		String sql = "select * from conductors where conductor_name=?";
		
		Conductor conductor = jdbcTemplate.queryForObject(sql, new ConductorRowMapper(), conductorName);
		
		return conductor;
	}

	@Override
	public void update(ConductorDTO conductorDTO) {
		
		String sql7 = "update conductors set lastname=?, email=?, address=?, pincode=?, contact_number=?, licence_number=?, authority_number=?, expiry_date=?, state_issued=? where conductor_name=?";
		
		jdbcTemplate.update(sql7,conductorDTO.getLastname(),conductorDTO.getEmail(),conductorDTO.getAddress(),conductorDTO.getPincode(),conductorDTO.getContact_number(),conductorDTO.getLicence_number(),conductorDTO.getAuthority_number(),conductorDTO.getExpiry_date(),conductorDTO.getState_issued(),conductorDTO.getConductor_name());		
	}

	@Override
	public List<Conductor> searchConductor(String conductorName) {
		String sql = "SELECT * FROM javaproject.conductors where conductor_name=?";
		
		List<Conductor> listOfDrivers = jdbcTemplate.query(sql, new ConductorRowMapper(),conductorName);
		
		return listOfDrivers;
	}

	@Override
	public List<EnabledConductor> enableConductors() {
		
		String sql = "select * from enableconductor";
		
		List<EnabledConductor> conductorList = jdbcTemplate.query(sql, new EnableCRowMapper());
		
		return conductorList;
	}

}
