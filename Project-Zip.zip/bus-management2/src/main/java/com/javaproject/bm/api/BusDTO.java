package com.javaproject.bm.api;

public class BusDTO {

	private int bus_id;
	private String bus_no;
	private float arrival_time;
	private float dispater_time;
	private String driver;
	private String conductor;
	private String from_where;
	private String to_where;

	public int getBus_id() {
		return bus_id;
	}

	public void setBus_id(int bus_id) {
		this.bus_id = bus_id;
	}

	public String getBus_no() {
		return bus_no;
	}

	public void setBus_no(String bus_no) {
		this.bus_no = bus_no;
	}

	public float getArrival_time() {
		return arrival_time;
	}

	public void setArrival_time(float arrival_time) {
		this.arrival_time = arrival_time;
	}

	public float getDispater_time() {
		return dispater_time;
	}

	public void setDispater_time(float dispater_time) {
		this.dispater_time = dispater_time;
	}
	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getConductor() {
		return conductor;
	}

	public void setConductor(String conductor) {
		this.conductor = conductor;
	}
	

	public String getFrom_where() {
		return from_where;
	}

	public void setFrom_where(String from_where) {
		this.from_where = from_where;
	}

	public String getTo_where() {
		return to_where;
	}

	public void setTo_where(String to_where) {
		this.to_where = to_where;
	}

	@Override
	public String toString() {
		return "BusDTO [bus_id=" + bus_id + ", bus_no=" + bus_no + ", arrival_time=" + arrival_time + ", dispater_time="
				+ dispater_time + ", driver=" + driver + ", conductor=" + conductor + ", from_where=" + from_where
				+ ", to_where=" + to_where + "]";
	}

	


}
