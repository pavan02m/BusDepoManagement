package com.javaproject.bm.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.javaproject.bm.api.Staff;
import com.javaproject.bm.api.StaffDTO;
import com.javaproject.bm.rowMapper.staffRowMapper;

@Repository
public class StaffDAOImpl implements StaffDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public List<Staff> loadStaff() {
		String sql = "SELECT * FROM javaproject.staff";
		List<Staff> staffList = jdbcTemplate.query(sql, new staffRowMapper());
		System.out.println(staffList);
		return staffList;
	}
	
	@Override
	public void saveStaff(StaffDTO staffDTO) {
		
		java.lang.Object[] sqlparameter = { staffDTO.getEmp_name(),staffDTO.getEmp_lastname(),staffDTO.getEmail(),staffDTO.getAddress(),staffDTO.getPincode(),staffDTO.getContact_number(),staffDTO.getDesignation()};
		
		String sql = "insert into staff(emp_name, emp_lastname, email, address, pincode, contact_number, designation) values(?,?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql, sqlparameter);
	}

	@Override
	public Staff getStaff(int staffId) {
	
		String sql = "select * from staff where emp_id = ?";
		
		Staff staff = jdbcTemplate.queryForObject(sql, new staffRowMapper(), staffId);
		
		return staff;
	}

	@Override
	public void update(StaffDTO staffDTO) {
		
		String sql = "update staff set  emp_name = ?, emp_lastname = ?, email = ?, address = ?, pincode = ?, contact_number = ?, designation = ? where emp_id=?";
		
		jdbcTemplate.update(sql,staffDTO.getEmp_name(), staffDTO.getEmp_lastname(), staffDTO.getEmail(), staffDTO.getAddress(), staffDTO.getPincode(), staffDTO.getContact_number(),staffDTO.getDesignation(),staffDTO.getEmp_id());
	}

	@Override
	public void deleteStaff(int staffId) {
		String sql = "delete from staff where emp_id = ?";
		
		jdbcTemplate.update(sql, staffId);
	}

	

}
