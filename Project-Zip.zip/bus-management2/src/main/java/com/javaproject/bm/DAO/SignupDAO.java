package com.javaproject.bm.DAO;

import com.javaproject.bm.api.UserDTO;

public interface SignupDAO {
	
	void saveUser(UserDTO userDTO);
}
