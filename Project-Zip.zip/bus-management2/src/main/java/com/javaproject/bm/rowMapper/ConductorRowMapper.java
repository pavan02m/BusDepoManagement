package com.javaproject.bm.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.javaproject.bm.api.Conductor;

public class ConductorRowMapper implements RowMapper<Conductor>{

	@Override
	public Conductor mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Conductor conductor = new Conductor();
		
		conductor.setConductor_name(rs.getString("conductor_name"));
		conductor.setLastname(rs.getString("lastname"));
		conductor.setEmail(rs.getString("email"));
		conductor.setAddress(rs.getString("address"));
		conductor.setPincode(rs.getInt("pincode"));
		conductor.setContact_number(rs.getBigDecimal("contact_number"));
		conductor.setLicence_number(rs.getString("licence_number"));
		conductor.setAuthority_number(rs.getString("authority_number"));
		conductor.setExpiry_date(rs.getString("expiry_date"));
		conductor.setState_issued(rs.getString("state_issued"));
		
		return conductor;
	}
	
}
