package com.javaproject.bm.DAO;

import java.util.List;

import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Repository;

import com.javaproject.bm.api.Bus;
import com.javaproject.bm.api.BusDTO;

import com.javaproject.bm.rowMapper.BusRowMapper;

@Repository
public class BusDAOimpl implements BusDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<Bus> loadBuses() {
		
		try {
			String sql3 = "SELECT * FROM javaproject.buses";
	
			List<Bus> listOfBus = jdbcTemplate.query(sql3, new BusRowMapper());
	
			return listOfBus;
		}catch(DataIntegrityViolationException e) {
			System.out.println(e);
	        throw new AccessDeniedException("Access denied", e);
	    }
	}

	@Override
	public void saveBus(BusDTO busDTO) {
		
			java.lang.Object[] sqlparameters = { busDTO.getBus_no(), busDTO.getArrival_time(), busDTO.getDispater_time(),busDTO.getDriver(),busDTO.getConductor(),busDTO.getFrom_where(),busDTO.getTo_where()};
	
			String sql4 = "insert into buses(bus_no,arrival_time,dispater_time,driver,conductor,from_where,to_where) values(?,?,?,?,?,?,?)";
	
			jdbcTemplate.update(sql4, sqlparameters);
			
		}

	@Override
	public Bus getBus(int busID) {

		String sql = "SELECT * FROM buses WHERE bus_id = ?";
		Bus bus = jdbcTemplate.queryForObject(sql, new BusRowMapper(), busID);

		return bus;
	}

	@Override
	public void update(BusDTO busDTO) {
		
		String sql = "update buses set bus_no = ?, arrival_time = ? , dispater_time= ?, driver= ?, conductor= ?, from_where=?, to_where=? where bus_id = ?;";
		jdbcTemplate.update(sql, busDTO.getBus_no(), busDTO.getArrival_time(), busDTO.getDispater_time(),
				busDTO.getDriver(), busDTO.getConductor(),busDTO.getFrom_where(),busDTO.getTo_where(),busDTO.getBus_id());
		System.out.println("Record updated...");
	}

	@Override
	public void deleteBus(int busID) {
		// TODO Auto-generated method stub
		String sql = "delete from buses where bus_id = ?";
		jdbcTemplate.update(sql, busID);

	}

	@Override
	public List<Bus> searchBus(int busId) {
		
		String sql3 = "SELECT * FROM javaproject.buses where bus_id=?";

		List<Bus> listOfBus = jdbcTemplate.query(sql3, new BusRowMapper(), busId);
		
		return listOfBus;
	}

}
