package com.javaproject.bm.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.javaproject.bm.api.AdminNotificationDTO;
import com.javaproject.bm.api.EmpNotification;
import com.javaproject.bm.api.EmpNotificationDTO;
import com.javaproject.bm.rowMapper.EmpNotifiactionRowMapper;

@Repository
public class EmpNotificationDAOImpl implements EmpnotificationDAO {


	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public void applyLeave(EmpNotificationDTO empNotificationDTO, AdminNotificationDTO adminNotificationDTO) {

		String sql = "insert into admin_notification(emp_name, from_date, to_date, reason) values(?,?,?,?)";
		String sql2 = "insert into emp_notification(name, from_date, to_date, reason, status) values(?,?,?,?,?)";
		
		jdbcTemplate.update(sql, adminNotificationDTO.getName(),adminNotificationDTO.getFrom(),adminNotificationDTO.getTo(),adminNotificationDTO.getReason());
		jdbcTemplate.update(sql2, empNotificationDTO.getName(),empNotificationDTO.getFrom(),empNotificationDTO.getTo(),empNotificationDTO.getReason()," ");
		System.out.println("request send successfully!");
	}

	@Override
	public List<EmpNotification> loadNotifications() {
		String sql = "select * from emp_notification";
		
		List<EmpNotification> empNotificationList = jdbcTemplate.query(sql,new EmpNotifiactionRowMapper());
		
		return empNotificationList;
	}

	@Override
	public void responseRequest(String name) {
	
		String sql = "delete from emp_notification where name=?";
		String sql2 = "update drivers set enabled=? where driver_name=?";
				
		jdbcTemplate.update(sql, name);
		jdbcTemplate.update(sql2,"enable", name);
		
	}	
	
}
