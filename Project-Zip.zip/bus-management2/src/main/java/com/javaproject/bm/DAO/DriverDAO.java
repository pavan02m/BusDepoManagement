package com.javaproject.bm.DAO;

import java.util.List;

import com.javaproject.bm.api.Driver;
import com.javaproject.bm.api.DriverDTO;
import com.javaproject.bm.api.EnabledDriver;

public interface DriverDAO {

	List<Driver> loadDrivers();
	
	void saveDriver(DriverDTO driverDTO);
	
	Driver getDriver(String driverName);

	void update(DriverDTO driverDTO);

	void deleteBus(String driverName);

	List<Driver> searchDriver(String driverName);

	List<EnabledDriver> enableDrivers();

}
