package com.javaproject.bm.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.javaproject.bm.api.Driver;
import com.javaproject.bm.api.EnabledDriver;

public class enabledRowMapper implements RowMapper<EnabledDriver> {

	@Override
	public EnabledDriver mapRow(ResultSet rs, int rowNum) throws SQLException {
		EnabledDriver driver = new EnabledDriver();
		
		driver.setDriver_name(rs.getString("driver_name"));
		
		return driver;
	}

}
