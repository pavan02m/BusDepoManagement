package com.javaproject.bm.rowMapper;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.javaproject.bm.api.AdminNotification;

public class AdminNotificationRowmapper implements RowMapper<AdminNotification> {

	@Override
	public AdminNotification mapRow(ResultSet rs, int rowNum) throws SQLException {
		AdminNotification adminNotification = new AdminNotification();
		
		adminNotification.setNotifi_id(rs.getInt("notifi_id"));
		adminNotification.setName(rs.getString("emp_name"));
		adminNotification.setFrom(rs.getString("from_date"));
		adminNotification.setTo(rs.getString("to_date"));
		adminNotification.setReason(rs.getString("reason"));
		
		return adminNotification;
	}

	

}
