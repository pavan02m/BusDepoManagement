package com.javaproject.bm.DAO;

public class DriverDoesNotExixtsException extends Exception {

	 private static final long serialVersionUID = 1L; 
	 
	    public DriverDoesNotExixtsException() { 
	        super(); 
	    } 
	 
	    public DriverDoesNotExixtsException(String message) { 
	        super(message); 
	    } 
	 
	    public DriverDoesNotExixtsException(Throwable cause) { 
	        super(cause); 
	    } 
	 
	    public DriverDoesNotExixtsException(String message, Throwable cause) { 
	        super(message, cause); 
	    } 
}
