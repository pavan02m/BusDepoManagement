package com.javaproject.bm.DAO;

import java.util.List;

import com.javaproject.bm.api.AdminNotification;

public interface AdNotificationDAO {

	List<AdminNotification> loadNotifications();

	void acceptRequest(String name);

	void rejectRequest(String name);

	

	
}
