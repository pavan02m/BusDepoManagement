package com.javaproject.bm.api;

public class AdminNotification {
	private int notifi_id;
	private String name;
	private String from;
	private String to;
	private String reason;
	
	public int getNotifi_id() {
		return notifi_id;
	}
	public void setNotifi_id(int notifi_id) {
		this.notifi_id = notifi_id;
	}
	
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void setTo(String to) {
		this.to = to;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	@Override
	public String toString() {
		return "AdminNotification [notifi_id=" + notifi_id + ", name=" + name + ", from=" + from + ", to=" + to
				+ ", reason=" + reason + "]";
	}
	
	
}
