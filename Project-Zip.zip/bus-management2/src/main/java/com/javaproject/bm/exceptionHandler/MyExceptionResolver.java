/*
 * package com.javaproject.bm.exceptionHandler;
 * 
 * import java.lang.System.Logger;
 * 
 * import javax.servlet.http.HttpServletRequest; import
 * javax.servlet.http.HttpServletResponse;
 * 
 * import org.springframework.dao.DataIntegrityViolationException; import
 * org.springframework.stereotype.Component; import
 * org.springframework.web.bind.annotation.ExceptionHandler; import
 * org.springframework.web.servlet.HandlerExceptionResolver; import
 * org.springframework.web.servlet.ModelAndView;
 * 
 * @Component public class MyExceptionResolver implements
 * HandlerExceptionResolver {
 * 
 * @Override public ModelAndView resolveException(HttpServletRequest
 * httpServletRequest, HttpServletResponse httpServletResponse, Object o,
 * Exception e) { ModelAndView mav = new ModelAndView("error");
 * mav.addObject("msg", e.getMessage()); return mav; }
 * 
 * }
 */