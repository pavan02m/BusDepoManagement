package com.javaproject.bm.api;

public class EmployeeDTO {
	private String userName;
	private String passWord;
	private String role;
	
	public String getUsername() {
		return userName;
	}
	public void setUsername(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return passWord;
	}
	public void setPassword(String passWord) {
		this.passWord = passWord;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "EmployeeDTO [username=" + userName + ", password=" + passWord + ", role=" + role + "]";
	}

	
}
