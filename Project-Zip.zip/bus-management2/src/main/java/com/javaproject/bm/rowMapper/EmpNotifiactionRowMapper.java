package com.javaproject.bm.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.javaproject.bm.api.EmpNotification;

public class EmpNotifiactionRowMapper implements RowMapper<EmpNotification>{

	@Override
	public EmpNotification mapRow(ResultSet rs, int rowNum) throws SQLException {

		EmpNotification empNotification = new EmpNotification();
		
		empNotification.setName(rs.getString("name"));
		empNotification.setFrom(rs.getString("from_date"));
		empNotification.setTo(rs.getString("to_date"));
		empNotification.setReason(rs.getString("reason"));
		empNotification.setStatus(rs.getString("status"));
		
		return empNotification;
	}
	
}
