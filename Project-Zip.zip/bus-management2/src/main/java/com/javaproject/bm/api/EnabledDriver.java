package com.javaproject.bm.api;

public class EnabledDriver {
	private String driver_name;

	public String getDriver_name() {
		return driver_name;
	}

	public void setDriver_name(String driver_name) {
		this.driver_name = driver_name;
	}

	@Override
	public String toString() {
		return driver_name;
	}
	
}
