package com.javaproject.bm.api;

public class EnabledConductor {
	public String conductor_name;

	public String getConductor_name() {
		return conductor_name;
	}

	public void setConductor_name(String conductor_name) {
		this.conductor_name = conductor_name;
	}

	@Override
	public String toString() {
		return conductor_name;
	}
	
}
