package com.javaproject.bm.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.javaproject.bm.DAO.AdNotificationDAO;
import com.javaproject.bm.DAO.BusDAO;
import com.javaproject.bm.DAO.ConductorDAO;
import com.javaproject.bm.DAO.DriverDAO;
import com.javaproject.bm.DAO.EmpnotificationDAO;
import com.javaproject.bm.DAO.SignupDAO;
import com.javaproject.bm.DAO.StaffDAO;
import com.javaproject.bm.api.AdminNotification;
import com.javaproject.bm.api.AdminNotificationDTO;
import com.javaproject.bm.api.Bus;
import com.javaproject.bm.api.BusDTO;
import com.javaproject.bm.api.Conductor;
import com.javaproject.bm.api.ConductorDTO;
import com.javaproject.bm.api.Driver;
import com.javaproject.bm.api.DriverDTO;
import com.javaproject.bm.api.EmpNotification;
import com.javaproject.bm.api.EmpNotificationDTO;
import com.javaproject.bm.api.EnabledConductor;
import com.javaproject.bm.api.EnabledDriver;
import com.javaproject.bm.api.Staff;
import com.javaproject.bm.api.StaffDTO;
import com.javaproject.bm.api.UserDTO;




@Controller
public class BusController {
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	private SignupDAO signupDAO;

	@Autowired
	private BusDAO busDAO;
	
	@Autowired
	private DriverDAO driverDAO;
	
	@Autowired
	private ConductorDAO conductorDAO;

	@Autowired
	private AdNotificationDAO adNotificationDAO;
	
	@Autowired
	private EmpnotificationDAO empNotificationDAO;
	
	@Autowired
	private StaffDAO staffDAO;
	
	private static final Logger logger = LoggerFactory.getLogger(BusController.class);
	// LOGIN PAGE 
	
	@GetMapping("/mylogin")
	public String login() {
		
		return "admin";
	}
	
	@GetMapping("/index")
	public String index() {
		
		return "index";
	}
	
	@GetMapping("/emplogin")
	public String emplogin() {
		
		return "emplogin";
	}
	
	@GetMapping("/dashboard")
	public String dashboard() {
		
		return "dashboard";
	}
	
	@GetMapping("/pannelselection")
	public String pannelselection() {
		return "panelselection";
	}
	
	/*
	 * @GetMapping("/driverdashboard") public String empdriver(){
	 * 
	 * return "empdriver"; }
	 */
		
	@GetMapping("/accessdenied")
	public String accessdenied() {
		return "accessdenied";
	}
	
	@GetMapping("/driverdashboard")
	public String driverdashboard() {
		return "drdashboard";
	}

	@GetMapping("/conductordashboard")
	public String conductordashboard() {
		return "cndashboard";
	}
	
	
	@GetMapping("/")
	private String singIn(@ModelAttribute("userdto") UserDTO userDTO) {
		
		return "index";
	}
	
	@PostMapping("/signin-process")
	public String processSignIn(UserDTO userDTO) {
		
		System.out.println(userDTO);
		
		//password encoding
		
		String encodepassword = passwordEncoder.encode(userDTO.getPassword());
		userDTO.setPassword(encodepassword);
		
		//writting logic to save user
		
		signupDAO.saveUser(userDTO);
		
		return "redirect:/mylogin";
	}

	
	
	
	// BUS PAGE DISPLAY AND ADD
	
	@GetMapping("/busList")
	public String showBuses(Model model) {
		// call service to get the data
			List<Bus> busList = busDAO.loadBuses();
			model.addAttribute("buses", busList);
			
		return "bus";

	}
	
	@GetMapping("/addBus")
	private String addBus(Model model,final RedirectAttributes redirectAttributes) {
		BusDTO busDTO = new BusDTO();
		List<EnabledDriver> driverList = driverDAO.enableDrivers();
		model.addAttribute("eabledrivers", driverList);
		List<EnabledConductor> conductorList = conductorDAO.enableConductors();
		model.addAttribute("enableconductor", conductorList);
		model.addAttribute("bus",busDTO);
		
		return "add-bus";
	}
	
	
	@PostMapping("/save-bus")
	private String saveBus(BusDTO busDTO) {
		
		System.out.println(busDTO);
		
				// do DAO call t0 save Bus
				busDAO.saveBus(busDTO);

		return "redirect:/busList";
	} 
	
	// Update Bus
	@GetMapping("/updateBus")
	private String updateBus(@RequestParam("busID") int busID,Model model) {
		// give a user object to fetch the data
		System.out.println("Looking data for bus :"+ busID);
		
		 Bus theBus = busDAO.getBus(busID); 
		
		System.out.println(theBus);
		
		// sending student Data
		/*bus.setBus_no(theBus.getBus_no());
		bus.setArrival_time(theBus.getArrival_time());
		bus.setDispater_time(theBus.getDispater_time());
		bus.setDiver(theBus.getDiver());*/
		
		// OR
		model.addAttribute("bus", theBus);
		return "update-bus";
	}
	

	@PostMapping("/saveUpdatedBus")
	public String saveUpdatedBus(BusDTO busDTO) {
		
		busDAO.update(busDTO);
		
		return "redirect:/busList";
	}
	
	// DELETE BUS
	
	@GetMapping("/deleteBus")
	private String deleteBus(@RequestParam("busID") int busID,final RedirectAttributes redirectAttributes) {
		
		logger.debug("deleteBus() : {}", busID);
		// Capture Bus_no
		busDAO.deleteBus(busID);
		
		redirectAttributes.addFlashAttribute("css", "success");
		redirectAttributes.addFlashAttribute("msg", "Bus is deleted!");
		
		return "redirect:/busList";
	}
	

	// FOR SERACHING 

	@RequestMapping("/search")
	public String search(@RequestParam("keyword") int busId, Model model) {

		List<Bus> busList = busDAO.searchBus(busId);

		model.addAttribute("search", busList);

		return "searchBus";
	}
	
	
	
	
	//    DRIVER
	
	@GetMapping("/driverList")
	public String showDriver(Model model) {
		// call DAO to get the data
		List<Driver> driverList = driverDAO.loadDrivers();
		
		model.addAttribute("drivers", driverList);
		
		return "driver";

	}
	
	@GetMapping("/addDriver")
	private String addDriver(Model model) {
		
		DriverDTO driverDTO = new DriverDTO();
		
		model.addAttribute("driver",driverDTO);
		
		return "adddriver";
	}
	
	@PostMapping("/save-driver")
	private String saveDriver(DriverDTO driverDTO) {
		// Logic to save Driver
		System.out.println(driverDTO);
		// do DAO call t0 save Bus
		driverDAO.saveDriver(driverDTO);
		
		return "redirect:/driverList";
	} 
	
	@GetMapping("/updateDriver")
	private String updateDriver(@RequestParam("driverName") String driverName,Model model) {
		// give a user object to fetch the data
		System.out.println("Looking data for bus :"+ driverName);
		
		 Driver theDriver = driverDAO.getDriver(driverName); 
		
		System.out.println(theDriver);
		
		model.addAttribute("driver", theDriver);
		return "updatedriver";
	}
	
	@PostMapping("/saveUpdatedDriver")
	private String saveUpdatedDriver(DriverDTO driverDTO) {
		
		driverDAO.update(driverDTO);
		
		return "redirect:/driverList";
	}
	
	
	@GetMapping("deleteDriver")
	private String deleteBus(@RequestParam("driverName") String driverName) {
		// Do DAO call
		
		driverDAO.deleteBus(driverName);
		
		return "redirect:/driverList";
	}
	
	// Driver Search
	
	@RequestMapping("/searchD")
	public String searchD(@RequestParam("keyword") String driverName, Model model) {

		List<Driver> DriverList = driverDAO.searchDriver(driverName);
		
		System.out.println(DriverList);
		model.addAttribute("searchDriver", DriverList);

		return "searchdriver1";
	}
	
	@RequestMapping("/searchDriver")
	public String searchDriver(@RequestParam("keyword") String driverName, Model model) {
		
		List<Driver> DriverList = driverDAO.searchDriver(driverName);
		System.out.println(DriverList);
		EmpNotification empNotification = new EmpNotification();
		List<EnabledDriver> driverList = driverDAO.enableDrivers();
		List<EmpNotification> emp_Notification = empNotificationDAO.loadNotifications();
		
		model.addAttribute("empnotification", emp_Notification);
		System.out.println(emp_Notification);
		model.addAttribute("eabledrivers", driverList);
		model.addAttribute("leave", empNotification);
		model.addAttribute("searchDriver", DriverList);
		return "searchdriver";
	}
	
	
	
	//     CONDUCTOR
	
	@GetMapping("/conductorList")
	private String showConductor(Model model) {
		
		List<Conductor> conductorList = conductorDAO.loadConductors();
		model.addAttribute("conductors", conductorList);
		
		return "conductor";
	}
	
	@GetMapping("/addConductor")
	private String addConductor(Model model) {
		
		ConductorDTO conductorDTO = new ConductorDTO();
		model.addAttribute("conductor", conductorDTO);
		
		return "addConductor";
	}
	
	@PostMapping("/save-conductor")
	private String saveConductor(ConductorDTO conductorDTO) {
		
		conductorDAO.saveConductor(conductorDTO);
		
		return "redirect:/conductorList";
	}
	
	@GetMapping("/updateConductor")
	private String updateConductor(@RequestParam("ConductorName") String conductorName, Model model) {
		Conductor theConductor = conductorDAO.getConductor(conductorName);
		
		model.addAttribute("conductor", theConductor);
		
		return "updateconductor";
	}
	
	@PostMapping("/saveUpdatedConductor")
	private String saveUpdatedConductor(ConductorDTO conductorDTO) {
		
		conductorDAO.update(conductorDTO);
		
		return "redirect:/conductorList";
	}
	
	@GetMapping("deleteConductor")
	private String deleteConductor(@RequestParam("ConductorName") String conductorName) {
		
		conductorDAO.deleteConductor(conductorName);
		
		return "redirect:/conductorList";
	}
	
	@RequestMapping("/searchC")
	public String searchC(@RequestParam("keyword") String conductorName, Model model) {

		List<Conductor> ConductorList = conductorDAO.searchConductor(conductorName);
		
		System.out.println(ConductorList);
		model.addAttribute("searchConductor", ConductorList);

		return "searchconductor1";
	}

	
	//Admin Notification 
	@GetMapping("/adminNotification")
	public String adminNotification(Model model) {
		
		  List<AdminNotification> adminNotification = adNotificationDAO.loadNotifications();
		  model.addAttribute("notification", adminNotification);
		 
		return "adnotification";
	}
	
	//Apply For Leave
	@PostMapping("/applyingForLeave")
	public String applyingForLeave(EmpNotificationDTO empNotificationDTO, AdminNotificationDTO adminNotificationDTO) {
		
		empNotificationDAO.applyLeave(empNotificationDTO,adminNotificationDTO);
		
		return "confirmrequest";
	}
	
	@GetMapping("/acceptRequest")
	private String acceptRequest(@RequestParam("emp_name") String name) {
		
		adNotificationDAO.acceptRequest(name);
		
		return "redirect:/adminNotification";
	}
	
	@GetMapping("/rejectRequest")
	private String rejectRequest(@RequestParam("emp_name") String name) {
		
		adNotificationDAO.rejectRequest(name);
		
		return "redirect:/adminNotification";
	}
	
	
	@GetMapping("/cancelRequest")
	public String responseRequest(@RequestParam("emp_name") String name) {
		
		empNotificationDAO.responseRequest(name);
		
		return "responseRequest";
		
	}
	
	// STAFF 
	
	@GetMapping("/staffList")
	private String staffList(Model model) {
		
		List<Staff> staffList = staffDAO.loadStaff();
		model.addAttribute("staffs", staffList);
		
		return "staff";
	}
	
	@GetMapping("/addStaff")
	private String addStaff(Model model) {
		
		StaffDTO staffDTO = new StaffDTO();
		model.addAttribute("staff", staffDTO);
		
		return "addstaff";
	}
	
	@PostMapping("/save-staff")
	private String saveStaff(StaffDTO staffDTO) {
		
		staffDAO.saveStaff(staffDTO);
		
		return "redirect:/staffList";
	}
	
	@GetMapping("/updateStaff")
	private String updateStaff(@RequestParam("empID") int staffId, Model model) {
		
		Staff theStaff = staffDAO.getStaff(staffId);
		System.out.println(theStaff);
		model.addAttribute("staff", theStaff);
		
		return "updatestaff";
	}
	
	@PostMapping("/saveUpdatedStaff")
	private String saveUpdatedStaff(StaffDTO staffDTO) {
		
		staffDAO.update(staffDTO);
		
		return "redirect:/staffList";
	}
	
	@GetMapping("deleteSatff")
	private String deleteSatff(@RequestParam("empID") int staffId) {
		
		staffDAO.deleteStaff(staffId);
		
		return "redirect:/staffList";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	@ExceptionHandler(value=DuplicateKeyException.class)
	public String exceptionHandler(Model model) {
		
		String str = "Duplicate Key Exception";
		model.addAttribute("msg", str);
		
		return "DuplicateKeyException";
	}
	
	@ExceptionHandler(value = DataIntegrityViolationException.class)
	public String exceptionHandlera(Model model) {

		String str = "Please check filled Information something is mssing";
		model.addAttribute("msg", str);

		return "dataIntegrityEx";
	}

}

