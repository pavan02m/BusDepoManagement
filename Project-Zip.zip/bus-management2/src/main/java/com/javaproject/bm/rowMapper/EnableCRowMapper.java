package com.javaproject.bm.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.javaproject.bm.api.EnabledConductor;

public class EnableCRowMapper implements RowMapper<EnabledConductor>{

	@Override
	public EnabledConductor mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		EnabledConductor enabledConductor = new EnabledConductor();
		
		enabledConductor.setConductor_name(rs.getString("conductor_name"));
		
		return enabledConductor;
	}

}
