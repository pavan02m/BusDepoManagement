package com.javaproject.bm.api;

import java.math.BigDecimal;

public class Staff {
	private int emp_id;
	private String emp_name;
	private String emp_lastname;
	private String email;
	private String address;
	private int pincode;
	private BigDecimal contact_number;
	private String designation;
	
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getEmp_lastname() {
		return emp_lastname;
	}
	public void setEmp_lastname(String emp_lastname) {
		this.emp_lastname = emp_lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public BigDecimal getContact_number() {
		return contact_number;
	}
	public void setContact_number(BigDecimal contact_number) {
		this.contact_number = contact_number;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "Staff [emp_id=" + emp_id + ", emp_name=" + emp_name + ", emp_lastname=" + emp_lastname + ", email="
				+ email + ", address=" + address + ", pincode=" + pincode + ", contact_number=" + contact_number
				+ ", designation=" + designation + "]";
	}
	
	
	
	
}
