package com.javaproject.bm.rowMapper;

import java.sql.ResultSet;

import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.javaproject.bm.api.Staff;

public class staffRowMapper implements RowMapper<Staff> {

	@Override
	public Staff mapRow(ResultSet rs, int rowNum) throws SQLException {

		Staff staff = new Staff();
		
		staff.setEmp_id(rs.getInt("emp_id"));
		staff.setEmp_name(rs.getString("emp_name"));
		staff.setEmp_lastname(rs.getString("emp_lastname"));
		staff.setEmail(rs.getString("email"));
		staff.setAddress(rs.getString("address"));
		staff.setPincode(rs.getInt("pincode"));
		staff.setContact_number(rs.getBigDecimal("contact_number"));
		staff.setDesignation(rs.getString("designation"));
		return staff;
	}


}
