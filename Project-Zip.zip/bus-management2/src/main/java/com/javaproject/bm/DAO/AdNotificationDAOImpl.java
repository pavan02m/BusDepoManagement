package com.javaproject.bm.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.javaproject.bm.api.AdminNotification;
import com.javaproject.bm.rowMapper.AdminNotificationRowmapper;

@Repository
public class AdNotificationDAOImpl implements AdNotificationDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<AdminNotification> loadNotifications() {

		String sql = "select * from admin_notification";

		List<AdminNotification> notificationList = jdbcTemplate.query(sql, new AdminNotificationRowmapper());

		return notificationList;
	}

	@Override
	public void acceptRequest(String name) {

		String sql = "delete from admin_notification where emp_name=?";

		String sql2 = "update emp_notification set status=? where name=?";
		String sql3 = "update drivers set enabled=? where driver_name=?";

		jdbcTemplate.update(sql, name);

		jdbcTemplate.update(sql2, "Accepted", name);
		jdbcTemplate.update(sql3, "disable", name);

	}

	@Override
	public void rejectRequest(String name) {
		String sql = "delete from admin_notification where emp_name=?";
		String sql2 = "update emp_notification set status=? where name=?";
		
		jdbcTemplate.update(sql2, "Rejected", name);
		jdbcTemplate.update(sql, name);
	}

}
